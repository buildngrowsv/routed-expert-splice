"""prog-e4-routing-census: how OLMoE's 64 experts per layer are used on each domain, and the
base model's scores that every E4 arm is compared with.

Writes census.json (expert usage per domain and layer, the most domain-specific expert that
each plug-in arm copies, and the most used expert for comparison)
and base.json (validation losses and benchmark accuracy of the unchanged model).
"""
import argparse

import mlx.core as mx
import numpy as np

from common import textdata
from common.job import Job
from e4 import check, moe, shared
from e4.olmoe import load


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", type=int, default=None, help="tokens per domain for the census (default 1M)")
    ap.add_argument("--val-windows", type=int, default=None, help="default 64")
    ap.add_argument("--bench-items", type=int, default=None, help="default 500")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    if args.smoke:
        args.tokens, args.val_windows, args.bench_items = args.tokens or 32_768, args.val_windows or 4, args.bench_items or 20
    args.tokens, args.val_windows, args.bench_items = args.tokens or 1_000_000, args.val_windows or 64, args.bench_items or 500
    job = Job("prog-e4-routing-census", vars(args))
    model, _ = load()
    L = len(model.model.layers)
    selftest = check.selftest(model)
    job.log("plug-in implementation vs 65-expert reference:", selftest)
    if selftest["max_relative_error"] > 0.03 or selftest["new_expert_selected"] < 0.05:
        raise RuntimeError(f"PluggedMoE self-test failed: {selftest}")

    moe.census_wrap(model)
    usage = {}
    batch = 8
    for d in shared.DOMAINS:
        data = textdata.shard(d, shared.TOK, "train", args.tokens + shared.SEQ + 1)
        win = textdata.val_windows(data, shared.SEQ, max(1, args.tokens // shared.SEQ))
        blocks = moe.moe_blocks(model)
        for b in blocks:
            b.count = mx.zeros_like(b.count)
            b.weight = mx.zeros_like(b.weight)
            b.tokens = 0
        for i in range(0, len(win), batch):
            model(mx.array(win[i:i + batch, :-1]))
            mx.eval([(b.count, b.weight) for b in blocks])
            job.progress(f"census {d}", i + batch, len(win), 0)
        tokens = blocks[0].tokens
        usage[d] = dict(tokens=tokens,
                        count=np.stack([np.array(b.count) for b in blocks]) / tokens,   # share of tokens choosing each expert
                        weight=np.stack([np.array(b.weight) for b in blocks]) / tokens)  # mean routing weight
        job.log(d, "tokens", tokens)
    moe.unplug(model)

    report = {}
    for d in shared.DOMAINS:
        report[d] = dict(tokens=usage[d]["tokens"], top_by_weight=usage[d]["weight"].argmax(1).tolist(),
                         top_weight=usage[d]["weight"].max(1).round(4).tolist(),
                         count=usage[d]["count"].round(5).tolist(), weight=usage[d]["weight"].round(6).tolist())
    # Initialization sources. The pre-registered rule copies the most domain-specific expert
    # (moe.specific_experts). The most used expert (highest mean routing weight) is recorded
    # for comparison and for the --init most_used ablation.
    most_used, specific, ratios = {}, {}, {}
    for d in ("icelandic", "welsh"):
        most_used[d] = report[d]["top_by_weight"]
        specific[d], ratios[d] = moe.specific_experts(usage[d]["count"], usage["english"]["count"])
    report["most_used"] = most_used
    report["specific"] = specific
    report["specific_ratio"] = ratios
    report["choices_differ"] = {d: sum(a != b for a, b in zip(most_used[d], specific[d])) for d in specific}
    report["same_source_icelandic_welsh"] = dict(
        most_used=sum(a == b for a, b in zip(most_used["icelandic"], most_used["welsh"])),
        specific=sum(a == b for a, b in zip(specific["icelandic"], specific["welsh"])))
    # Overlap of the eight most used experts between domains, per layer.
    def top8(d):
        return [set(np.argsort(-usage[d]["weight"][l])[:8].tolist()) for l in range(L)]
    report["top8_overlap_icelandic_english"] = [len(a & b) for a, b in zip(top8("icelandic"), top8("english"))]
    report["top8_overlap_welsh_english"] = [len(a & b) for a, b in zip(top8("welsh"), top8("english"))]
    report["sources"] = specific
    job.save("census.json", report)

    sets = shared.val_sets(args.val_windows)
    base = dict(val=shared.val_losses(model, sets), bench=shared.benchmarks(model, args.bench_items),
                val_windows=args.val_windows, bench_items=args.bench_items)
    job.save("base.json", base)
    job.log("base", base)
    job.log("specific vs most used differ in", report["choices_differ"], "layers; same source for both languages:",
            report["same_source_icelandic_welsh"])
    job.finish("census_complete", sources=report["sources"], most_used=most_used, specific_ratio=ratios,
               choices_differ=report["choices_differ"], same_source_icelandic_welsh=report["same_source_icelandic_welsh"],
               base=base, selftest=selftest, top8_overlap_icelandic_english=report["top8_overlap_icelandic_english"])


if __name__ == "__main__":
    main()
