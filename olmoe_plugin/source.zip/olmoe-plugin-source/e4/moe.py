"""Plug-in experts for OLMoE's sparse feed-forward blocks.

``PluggedMoE`` wraps an original ``OlmoeSparseMoeBlock`` without copying or changing it.
The router gains one row per new expert. OLMoE applies the softmax to all router logits
before choosing the top 8 (``norm_topk_prob`` is false), so while a new expert is plugged
in it also lowers the weights of the original experts. New experts are dense SwiGLU
modules evaluated on every token; their output counts only where the extended router puts
them in the top 8. Unplugging restores the original module object, so the original
computation returns exactly.
"""
from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn
import numpy as np

N_OLD = 64


class PluggedMoE(nn.Module):
    def __init__(self, base, gate_w, up_w, down_w, rows, old_rows=None):
        """``gate_w``/``up_w`` [n, H, D], ``down_w`` [n, D, H], ``rows`` [n, D] for n new experts.

        ``old_rows`` [64, D], when given, replaces the original router rows (a trainable copy),
        so the original module is never modified.
        """
        super().__init__()
        self.base = base
        self.gate_w, self.up_w, self.down_w, self.rows = gate_w, up_w, down_w, rows
        if old_rows is not None:
            self.old_rows = old_rows
        self.record = False
        self.share = None  # [tokens, n] routing weight of each new expert, when record is on

    @property
    def n_new(self):
        return self.rows.shape[0]

    def __call__(self, x):
        base = self.base
        B, L, D = x.shape
        xf = x.reshape(-1, D)
        dt = xf.dtype
        old = xf @ self.old_rows.astype(dt).T if "old_rows" in self else base.gate(xf)
        logits = mx.concatenate([old, xf @ self.rows.astype(dt).T], axis=-1)
        p = mx.softmax(logits, axis=1, precise=True)
        k = base.top_k
        idx = mx.stop_gradient(mx.argpartition(-p, kth=k - 1, axis=-1)[..., :k])
        scores = mx.take_along_axis(p, idx, axis=-1)
        if base.norm_topk_prob:
            scores = scores / scores.sum(axis=-1, keepdims=True)
        is_new = idx >= N_OLD
        old_idx = mx.where(is_new, 0, idx)
        old_scores = mx.where(is_new, 0, scores)
        y = base.switch_mlp(xf, old_idx)
        y = (y * old_scores[..., None].astype(y.dtype)).sum(axis=-2)
        shares = []
        for j in range(self.n_new):
            w = mx.where(idx == N_OLD + j, scores, 0).sum(axis=-1)
            h = nn.silu(xf @ self.gate_w[j].astype(dt).T) * (xf @ self.up_w[j].astype(dt).T)
            y = y + w[:, None].astype(y.dtype) * (h @ self.down_w[j].astype(dt).T)
            shares.append(w)
        if self.record:
            self.share = mx.stack(shares, axis=-1)
        return y.reshape(B, L, D)


class CensusMoE(nn.Module):
    """Runs the original block unchanged and accumulates how each expert is used."""

    def __init__(self, base):
        super().__init__()
        self.base = base
        self.count = mx.zeros((N_OLD,), dtype=mx.float32)   # times in the top 8
        self.weight = mx.zeros((N_OLD,), dtype=mx.float32)  # summed routing weight
        self.tokens = 0

    def __call__(self, x):
        base = self.base
        xf = x.reshape(-1, x.shape[-1])
        p = mx.softmax(base.gate(xf), axis=1, precise=True).astype(mx.float32)
        k = base.top_k
        idx = mx.argpartition(-p, kth=k - 1, axis=-1)[..., :k]
        onehot = mx.zeros_like(p)
        onehot = mx.put_along_axis(onehot, idx, mx.ones(idx.shape, dtype=p.dtype), axis=-1)
        self.count = self.count + onehot.sum(0)
        self.weight = self.weight + (onehot * p).sum(0)
        self.tokens += xf.shape[0]
        return base(x)


def specific_experts(domain_share, english_share, top_k: int = 8, floor: float = 1e-4):
    """Per layer, the most domain-specific expert.

    ``domain_share`` and ``english_share`` are [layers, 64] fractions of tokens whose top 8
    includes each expert. Eligible experts are chosen for at least the layer average share of
    domain tokens (top_k / 64 = 1/8). Among them, pick the largest ratio of domain share to
    English share. Returns (expert per layer, ratio per layer).
    """
    domain_share = np.asarray(domain_share, dtype=np.float64)
    english_share = np.asarray(english_share, dtype=np.float64)
    mean = top_k / domain_share.shape[1]
    ratio = domain_share / (english_share + floor)
    ratio = np.where(domain_share >= mean, ratio, -np.inf)
    pick = ratio.argmax(1)
    return pick.astype(int).tolist(), ratio[np.arange(len(pick)), pick].round(3).tolist()


def moe_blocks(model):
    return [layer.mlp for layer in model.model.layers]


def originals(model):
    """The original sparse blocks, whether or not something is wrapped around them."""
    return [getattr(m, "base", m) for m in moe_blocks(model)]


def plug(model, experts: list[dict]):
    """Wrap every layer. ``experts`` holds one dict per new expert with per-layer arrays
    ``gate_w`` [L, H, D], ``up_w`` [L, H, D], ``down_w`` [L, D, H], ``rows`` [L, D]."""
    bases = originals(model)
    for i, layer in enumerate(model.model.layers):
        stack = lambda key: mx.stack([e[key][i] for e in experts])  # noqa: E731
        layer.mlp = PluggedMoE(bases[i], stack("gate_w"), stack("up_w"), stack("down_w"), stack("rows"))
    return model


def unplug(model):
    for i, base in enumerate(originals(model)):
        model.model.layers[i].mlp = base
    return model


def census_wrap(model):
    bases = originals(model)
    for i, layer in enumerate(model.model.layers):
        layer.mlp = CensusMoE(bases[i])
    return model


def copy_expert(model, sources: list[int], dtype=mx.float32) -> dict:
    """A new expert per layer copied from expert ``sources[layer]``, router row included."""
    out = {"gate_w": [], "up_w": [], "down_w": [], "rows": []}
    for i, base in enumerate(originals(model)):
        e = sources[i]
        sw = base.switch_mlp
        out["gate_w"].append(sw.gate_proj.weight[e].astype(dtype))
        out["up_w"].append(sw.up_proj.weight[e].astype(dtype))
        out["down_w"].append(sw.down_proj.weight[e].astype(dtype))
        out["rows"].append(base.gate.weight[e].astype(dtype))
    return {k: mx.stack(v) for k, v in out.items()}


def expert_from_plugged(model, j: int = 0) -> dict:
    blocks = moe_blocks(model)
    return {k: mx.stack([getattr(b, k)[j] for b in blocks]) for k in ("gate_w", "up_w", "down_w", "rows")}


class LoRALinear(nn.Module):
    """y = W x + scale * B A x with W frozen, A random, B zero."""

    def __init__(self, base: nn.Linear, rank: int, scale: float = 1.0):
        super().__init__()
        self.base = base
        d_out, d_in = base.weight.shape
        self.lora_a = mx.random.normal((rank, d_in), dtype=mx.float32) * (d_in ** -0.5)
        self.lora_b = mx.zeros((d_out, rank), dtype=mx.float32)
        self.scale = scale

    def __call__(self, x):
        dt = x.dtype
        return self.base(x) + self.scale * ((x @ self.lora_a.astype(dt).T) @ self.lora_b.astype(dt).T)


def remove_lora(model):
    for layer in model.model.layers:
        att = layer.self_attn
        for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
            mod = getattr(att, name)
            if isinstance(mod, LoRALinear):
                setattr(att, name, mod.base)
    return model


def add_lora(model, rank: int):
    for layer in model.model.layers:
        att = layer.self_attn
        for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
            setattr(att, name, LoRALinear(getattr(att, name), rank))
    return model
