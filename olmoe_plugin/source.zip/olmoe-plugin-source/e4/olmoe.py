"""Load OLMoE-1B-7B-0924 at its pinned revision.

The published config omits ``rms_norm_eps``. Hugging Face's OlmoeConfig defaults it to
1e-5, which is what the model was trained with, so it is supplied here.
"""
from mlx_lm.utils import load as mlx_load

from common.paths import model_path

CONFIG = {"rms_norm_eps": 1e-5}


def load():
    model, tok = mlx_load(str(model_path("olmoe")), model_config=CONFIG)
    return model, tok
