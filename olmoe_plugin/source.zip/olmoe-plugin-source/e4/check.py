"""Check PluggedMoE against a reference that stores the new expert as a 65th row of the
original expert arrays and runs OLMoE's own routing code."""
import mlx.core as mx
import numpy as np
from mlx_lm.models.switch_layers import SwitchGLU

from e4 import moe


def reference(base, extra, x):
    """OLMoE's routing with 64 + n experts held in one SwitchGLU."""
    n = extra["rows"].shape[0]
    sw = SwitchGLU(x.shape[-1], extra["gate_w"].shape[1], moe.N_OLD + n)
    sw.gate_proj.weight = mx.concatenate([base.switch_mlp.gate_proj.weight, extra["gate_w"].astype(mx.bfloat16)])
    sw.up_proj.weight = mx.concatenate([base.switch_mlp.up_proj.weight, extra["up_w"].astype(mx.bfloat16)])
    sw.down_proj.weight = mx.concatenate([base.switch_mlp.down_proj.weight, extra["down_w"].astype(mx.bfloat16)])
    xf = x.reshape(-1, x.shape[-1])
    logits = mx.concatenate([base.gate(xf), xf @ extra["rows"].astype(xf.dtype).T], axis=-1)
    p = mx.softmax(logits, axis=1, precise=True)
    idx = mx.argpartition(-p, kth=base.top_k - 1, axis=-1)[..., :base.top_k]
    scores = mx.take_along_axis(p, idx, axis=-1)
    y = (sw(xf, idx) * scores[..., None]).sum(axis=-2)
    return y.reshape(x.shape), idx


def selftest(model, layer: int = 3, tokens: int = 256, seed: int = 0) -> dict:
    """Relative error of PluggedMoE vs the reference on random hidden states, plus how often the
    new expert was selected (it must be selected for the test to mean anything)."""
    base = moe.originals(model)[layer]
    D = base.gate.weight.shape[1]
    H = base.switch_mlp.gate_proj.weight.shape[1]
    k = mx.random.split(mx.random.key(seed), 5)
    extra = dict(gate_w=mx.random.normal((1, H, D), key=k[0]) * 0.02, up_w=mx.random.normal((1, H, D), key=k[1]) * 0.02,
                 down_w=mx.random.normal((1, D, H), key=k[2]) * 0.02,
                 rows=base.gate.weight[[5]].astype(mx.float32) * 1.5)
    x = (mx.random.normal((1, tokens, D), key=k[3]) * 0.5).astype(mx.bfloat16)
    plugged = moe.PluggedMoE(base, **extra)
    got = plugged(x).astype(mx.float32)
    want, idx = reference(base, extra, x)
    want = want.astype(mx.float32)
    rel = float((mx.abs(got - want).max() / mx.abs(want).max()).item())
    chosen = float((np.array(idx) == moe.N_OLD).any(-1).mean())
    return dict(max_relative_error=rel, new_expert_selected=chosen)


if __name__ == "__main__":
    from e4.olmoe import load
    model, _ = load()
    print(selftest(model))
