"""Pieces shared by the E4 jobs: data, evaluation, optimizer, checkpoints and atlas output."""
from __future__ import annotations

import os
import time
from pathlib import Path

import mlx.core as mx
import numpy as np
from mlx.utils import tree_flatten

from common import evals, lm, textdata
from common.atlas_bundle import Bundle, grid_order
from e4 import moe

TOK = "olmoe"
SEQ = 1024
DOMAINS = ("icelandic", "welsh", "english", "python")
PROBES = {
    "icelandic": "Reykjavík er höfuðborg Íslands og stærsta borg landsins. Þar búa um það bil tveir "
                 "þriðju hlutar þjóðarinnar, og margir vinna við ferðaþjónustu eða fiskveiðar.",
    "english": "The capital of France is Paris, and the largest city in Germany is Berlin. Most people "
               "in these cities travel to work by train, bus or bicycle rather than by car.",
}


def encoder():
    tok = textdata.tokenizer(TOK)
    return lambda s: tok.encode(s, add_special_tokens=False).ids


def val_sets(windows: int) -> dict[str, np.ndarray]:
    return {d: textdata.val_windows(textdata.shard(d, TOK, "val", windows * (SEQ + 1) + SEQ), SEQ, windows)
            for d in DOMAINS}


def val_losses(model, sets: dict, batch: int = 8) -> dict[str, float]:
    fn = lambda ids: model(ids)  # noqa: E731
    return {d: lm.mean_loss(fn, w, batch=batch) for d, w in sets.items()}


def benchmarks(model, count: int) -> dict[str, float]:
    enc = encoder()
    fn = lambda ids: model(ids)  # noqa: E731
    return {name: evals.multiple_choice(fn, enc, evals.items(name, count)) for name in ("arc_easy", "hellaswag")}


def routing_share(model, sets: dict, windows: int = 4) -> dict:
    """Per layer: fraction of tokens whose top 8 includes each new expert, and its mean weight."""
    blocks = [b for b in moe.moe_blocks(model) if isinstance(b, moe.PluggedMoE)]
    if not blocks:
        return {}
    out = {}
    for b in blocks:
        b.record = True
    for d, w in sets.items():
        hits, weight = [], []
        for i in range(0, min(windows, len(w)), 2):
            model(mx.array(w[i:i + 2, :-1]))
            hits.append(np.stack([np.array((b.share > 0).astype(mx.float32).mean(0)) for b in blocks]))
            weight.append(np.stack([np.array(b.share.astype(mx.float32).mean(0)) for b in blocks]))
        out[d] = dict(selected=np.mean(hits, 0).round(4).tolist(), weight=np.mean(weight, 0).round(5).tolist())
    for b in blocks:
        b.record, b.share = False, None
    return out


def schedule(peak: float, steps: int, warmup: int):
    def lr(step):
        if step < warmup:
            return peak * (step + 1) / warmup
        t = (step - warmup) / max(1, steps - warmup)
        return peak * (0.1 + 0.9 * 0.5 * (1 + np.cos(np.pi * min(1.0, t))))
    return lr


class MasterAdamW:
    """AdamW with float32 master weights and moments for parameters stored in bf16 or fp32."""

    def __init__(self, params: dict, lr_fn, b1=0.9, b2=0.95, eps=1e-8, weight_decay=0.0, clip=1.0):
        self.dtypes = {k: v.dtype for k, v in params.items()}
        self.master = {k: v.astype(mx.float32) for k, v in params.items()}
        self.m = {k: mx.zeros(v.shape, dtype=mx.float32) for k, v in params.items()}
        self.v = {k: mx.zeros(v.shape, dtype=mx.float32) for k, v in params.items()}
        mx.eval(self.master, self.m, self.v)
        self.lr_fn, self.b1, self.b2, self.eps, self.wd, self.clip = lr_fn, b1, b2, eps, weight_decay, clip
        self.step = 0

    def apply(self, grads: dict) -> tuple[list, float]:
        """Update masters from ``grads`` (flat names). Returns (new params as (name, array), grad norm)."""
        sq = [mx.sum(mx.square(g.astype(mx.float32))) for g in grads.values()]
        norm = float(mx.sqrt(mx.sum(mx.stack(sq))).item())
        scale = min(1.0, self.clip / (norm + 1e-6))
        lr = self.lr_fn(self.step)
        self.step += 1
        c1, c2 = 1 - self.b1 ** self.step, 1 - self.b2 ** self.step
        out = []
        for k in list(grads):
            g = grads.pop(k).astype(mx.float32) * scale
            m = self.b1 * self.m[k] + (1 - self.b1) * g
            v = self.b2 * self.v[k] + (1 - self.b2) * mx.square(g)
            w = self.master[k]
            w = w - lr * ((m / c1) / (mx.sqrt(v / c2) + self.eps) + self.wd * w)
            self.m[k], self.v[k], self.master[k] = m, v, w
            new = w.astype(self.dtypes[k])
            mx.eval(m, v, w, new)
            out.append((k, new))
        return out, norm

    def save(self, directory: Path, extra: dict) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        arrays = {}
        for prefix, tree in (("master", self.master), ("m", self.m), ("v", self.v)):
            arrays.update({f"{prefix}:{k}": a for k, a in tree.items()})
        tmp = directory / f".state.{os.getpid()}.safetensors"
        mx.save_safetensors(str(tmp), arrays, metadata={"step": str(self.step), **{k: str(v) for k, v in extra.items()}})
        os.replace(tmp, directory / "state.safetensors")

    def load(self, directory: Path) -> dict | None:
        path = directory / "state.safetensors"
        if not path.exists():
            return None
        arrays, meta = mx.load(str(path), return_metadata=True)
        for key, a in arrays.items():
            prefix, name = key.split(":", 1)
            getattr(self, prefix)[name] = a
        self.step = int(meta.pop("step"))
        return meta

    def params(self) -> list:
        return [(k, w.astype(self.dtypes[k])) for k, w in self.master.items()]


def flat(tree) -> dict:
    return dict(tree_flatten(tree))


# ---------------------------------------------------------------- atlas

def probe_ids(max_tokens: int = 48) -> tuple[np.ndarray, list[str]]:
    enc = encoder()
    ids, owner = [], []
    for name, text in PROBES.items():
        t = enc(text)[:max_tokens]
        ids += t
        owner += [name] * len(t)
    return np.asarray(ids, dtype=np.int32), owner


def capture(model, ids: np.ndarray) -> dict:
    """Residual states, logit-lens top token and new-expert routing share for each probe separately."""
    _, owner = probe_ids()
    states, top, prob, share = [], [], [], []
    start = 0
    for name in PROBES:
        n = owner.count(name)
        x = mx.array(ids[start:start + n])[None]
        blocks = [b for b in moe.moe_blocks(model) if isinstance(b, moe.PluggedMoE)]
        for b in blocks:
            b.record = True
        _, kept = lm.forward(model, x, keep=set(range(len(model.model.layers) + 1)))
        st = mx.stack([kept[i][0] for i in sorted(kept)])
        z = lm.logits_from_hidden(model, st).astype(mx.float32)
        p = mx.softmax(z, axis=-1)
        t = mx.argmax(p, axis=-1)
        states.append(np.array(st.astype(mx.float32)))
        top.append(np.array(t))
        prob.append(np.array(mx.take_along_axis(p, t[..., None], axis=-1)[..., 0]))
        if blocks:
            share.append(np.stack([np.array(b.share.astype(mx.float32)) for b in blocks]))
            for b in blocks:
                b.record, b.share = False, None
        start += n
    out = dict(states=np.concatenate(states, 1), top=np.concatenate(top, 1), prob=np.concatenate(prob, 1))
    if share:
        out["share"] = np.concatenate(share, 1)  # [layers, items, n_new]
    return out


def _byte_decoder():
    """Inverse of the GPT-2 byte-to-unicode table used by OLMoE's byte-level tokenizer."""
    bs = list(range(ord("!"), ord("~") + 1)) + list(range(ord("¡"), ord("¬") + 1)) + list(range(ord("®"), ord("ÿ") + 1))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


_BYTES = _byte_decoder()


def token_text(tok, i: int) -> str:
    """Readable text of one token. Pieces of a multi-byte character show as hex bytes."""
    piece = tok.id_to_token(i) or ""
    raw = bytes(_BYTES[c] for c in piece if c in _BYTES) if all(c in _BYTES for c in piece) else None
    if raw is None:
        return tok.decode([i])
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return "".join(chr(b) if b < 128 else f"\\x{b:02x}" for b in raw)


def write_atlas(directory: Path, title: str, description: str, ids: np.ndarray, captures: dict,
                conditions: list[dict], compare: dict, frames: list[int] | None = None, notes: dict | None = None):
    """``captures`` maps run id -> capture dict (plus optional 'condition', 'step', 'label')."""
    tok = textdata.tokenizer(TOK)
    base = captures["base"]
    S, I, D = base["states"].shape
    b = Bundle(title, description)
    b["model"] = dict(name="OLMoE-1B-7B-0924", width=D, blocks=S - 1, grid=[32, D // 32])
    b["layer_labels"] = ["Embedding"] + [f"Block {i}" for i in range(1, S)]
    b["conditions"] = conditions
    if frames:
        b["frames"] = frames
    b["compare"] = dict(label="Change vs original OLMoE", ref=compare)
    runs = []
    for rid, c in captures.items():
        runs.append(dict(id=rid, condition=c.get("condition", rid), step=c.get("step", 0), parent=None,
                         states_from=0, label=c.get("label", rid)))
    b["runs"] = runs
    _, owner = probe_ids()
    b["items"] = [dict(kind="token", t=t, token=int(ids[t]), probe=owner[t]) for t in range(I)]
    b["answer_items"] = [I, I]
    b["default_item"] = owner.index("english") - 1
    used = set(int(x) for x in ids) | set(int(x) for c in captures.values() for x in np.unique(c["top"]))
    b["vocab"] = {str(i): token_text(tok, i) for i in sorted(used)}
    b["notes"] = dict(probes=PROBES, routing=(
        "routing/<run> holds the routing weight given to each plug-in expert, shape [blocks, items, new experts]. "
        "Zero means the expert was outside that token's top 8."), **(notes or {}))
    b.array("layout/channels", grid_order(base["states"].transpose(2, 0, 1).reshape(D, -1), 32, D // 32), "i32")
    b.array("scale/states", np.sqrt((base["states"] ** 2).mean(1)) + 1e-6, "f32")
    for rid, c in captures.items():
        b.array(f"states/{rid}", c["states"], "f16")
        b.array(f"lenstop/{rid}", c["top"], "i32")
        b.array(f"lensp/{rid}", c["prob"], "f16")
        if "share" in c:
            b.array(f"routing/{rid}", c["share"], "f16")
    return b.save(directory)


class Throughput:
    """Training tokens per second of step time only (evaluation and snapshots excluded)."""

    def __init__(self):
        self.seconds, self.tokens = 0.0, 0

    def add(self, n, seconds):
        self.tokens += n
        self.seconds += seconds

    def rate(self):
        r = self.tokens / self.seconds if self.seconds > 0 else 0.0
        self.seconds, self.tokens = 0.0, 0
        return r
