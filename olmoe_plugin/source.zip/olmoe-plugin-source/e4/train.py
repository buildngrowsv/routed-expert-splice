"""One E4 arm: adapt OLMoE-1B-7B to a new language and measure what it keeps.

    python run.py e4.train --arm plug            # prog-e4-plug
    python run.py e4.train --arm full --smoke

Every arm sees the same training windows of the new language (fixed seed), uses AdamW with
float32 master weights, 100 warmup steps and cosine decay to 10% of the peak rate, and is
scored on the same validation windows and benchmark items as the base model.
"""
import argparse
import shutil
import time

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_map
import numpy as np

from common import lm, textdata
from common.job import Budget, Job, read_json
from common.paths import job_output
from e4 import moe, shared
from e4.olmoe import load

ARMS = {
    "plug": dict(domain="icelandic", kind="plug", rows=True, router_all=False, lr=1e-4),
    "plug_fixed_router": dict(domain="icelandic", kind="plug", rows=False, router_all=False, lr=1e-4),
    "plug_router_all": dict(domain="icelandic", kind="plug", rows=True, router_all=True, lr=1e-4),
    "lora": dict(domain="icelandic", kind="lora", rank=384, lr=2e-4),
    "full": dict(domain="icelandic", kind="full", lr=2e-5),
    "plug_welsh": dict(domain="welsh", kind="plug", rows=True, router_all=False, lr=1e-4),
}
CENSUS_JOB = "prog-e4-routing-census"


def job_id(arm: str) -> str:
    return "prog-e4-" + arm.replace("_", "-")


def census_sources(args, model, domain, job):
    """Expert to copy in each layer under the chosen initialization rule."""
    key = "sources" if args.init == "specific" else "most_used"
    report = read_json(job_output(CENSUS_JOB) / "census.json")
    if report:
        return report[key][domain]
    if not args.smoke:
        raise FileNotFoundError(f"{CENSUS_JOB} has not run")
    job.log("smoke: quick census on 64k tokens per domain")
    moe.census_wrap(model)
    shares, weights = {}, {}
    for d in dict.fromkeys((domain, "english")):
        blocks = moe.moe_blocks(model)
        for b in blocks:
            b.count, b.weight, b.tokens = mx.zeros_like(b.count), mx.zeros_like(b.weight), 0
        w = textdata.val_windows(textdata.shard(d, shared.TOK, "train", 70_000), shared.SEQ, 64)
        for i in range(0, 64, 4):
            model(mx.array(w[i:i + 4, :-1]))
            mx.eval([(b.count, b.weight) for b in blocks])
        shares[d] = np.stack([np.array(b.count) / b.tokens for b in blocks])
        weights[d] = np.stack([np.array(b.weight) / b.tokens for b in blocks])
    moe.unplug(model)
    if args.init == "most_used":
        return weights[domain].argmax(1).astype(int).tolist()
    return moe.specific_experts(shares[domain], shares["english"])[0]


def build(model, spec, args, job):
    """Attach the arm's trainable parts and set which parameters train."""
    if spec["kind"] == "plug":
        sources = census_sources(args, model, spec["domain"], job)
        expert = moe.copy_expert(model, sources)
        if args.down_init == "zero":
            # The copy starts with no output: gate and up projections and the router row are
            # copied, the down projection is zero. It learns once its down projection moves.
            expert["down_w"] = mx.zeros_like(expert["down_w"])
        moe.plug(model, [expert])
        job.log(f"init {args.init}, down projection {args.down_init}: copying experts {sources}")
        model.freeze()
        for b in moe.moe_blocks(model):
            if spec["router_all"]:
                b.old_rows = b.base.gate.weight.astype(mx.float32)
            keys = ["gate_w", "up_w", "down_w"] + (["rows"] if spec["rows"] else []) + \
                   (["old_rows"] if spec["router_all"] else [])
            b.unfreeze(keys=keys, recurse=False)
        return dict(sources=sources, init=args.init, down_init=args.down_init)
    if spec["kind"] == "lora":
        moe.add_lora(model, spec["rank"])
        model.freeze()
        for layer in model.model.layers:
            for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
                getattr(layer.self_attn, name).unfreeze(keys=["lora_a", "lora_b"], recurse=False)
        return dict(rank=spec["rank"])
    model.unfreeze()
    return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", required=True, choices=sorted(ARMS))
    ap.add_argument("--tokens", type=int, default=50_000_000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--micro", type=int, default=1, help="split each batch into this many chunks (same update, less memory)")
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--eval-every", type=int, default=250)
    ap.add_argument("--val-windows", type=int, default=None, help="default 64 (4 in smoke)")
    ap.add_argument("--bench-items", type=int, default=None, help="default 500 (16 in smoke)")
    ap.add_argument("--down-init", choices=("zero", "copy"), default="zero",
                    help="plug arms: new expert's down projection starts at zero (registered) or copied")
    ap.add_argument("--job", default=None, help="job name when it differs from prog-e4-<arm> (ablations)")
    ap.add_argument("--init", choices=("specific", "most_used"), default="specific",
                    help="plug arms: copy the most domain-specific expert (registered) or the most used one")
    ap.add_argument("--steps", type=int, default=None, help="smoke only: number of training steps")
    ap.add_argument("--frames", type=int, default=5)
    ap.add_argument("--ckpt-minutes", type=float, default=None)
    ap.add_argument("--hours", type=float, default=4.0, help="wall-clock cap; stops early and reports tokens reached")
    ap.add_argument("--smoke-layers", type=int, default=None, help="smoke only: keep the first N layers")
    ap.add_argument("--memory-limit-gb", type=float, default=None, help="MLX allocation limit (for shared smoke tests)")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    if args.memory_limit_gb:
        mx.set_memory_limit(int(args.memory_limit_gb * 1e9))
    spec = dict(ARMS[args.arm])
    if args.lr:
        spec["lr"] = args.lr
    if args.smoke:
        args.tokens, args.eval_every = (args.steps or 12) * args.batch * shared.SEQ, 6
        args.val_windows, args.bench_items = args.val_windows or 4, args.bench_items or 16
        args.frames, args.ckpt_minutes = 3, args.ckpt_minutes or 0.5
    args.val_windows, args.bench_items = args.val_windows or 64, args.bench_items or 500
    ckpt_minutes = args.ckpt_minutes or (60 if spec["kind"] == "full" else 20)
    job = Job(args.job or job_id(args.arm), dict(vars(args), spec=spec))
    budget = Budget(args.hours - 0.25)  # leave time for final evaluation
    steps = args.tokens // (args.batch * shared.SEQ)
    warmup = min(100, max(1, steps // 10))

    model, _ = load()
    if args.smoke and args.smoke_layers:
        model.model.layers = model.model.layers[:args.smoke_layers]
    sets = shared.val_sets(args.val_windows)
    ref = mx.array(sets["english"][:2, :257])
    base_ref = model(ref[:, :-1])
    mx.eval(base_ref)
    probe, _ = shared.probe_ids()
    base_capture = shared.capture(model, probe)
    base = read_json(job_output(CENSUS_JOB) / "base.json")
    if base is None or base.get("val_windows") != args.val_windows:
        job.log("measuring base model")
        base = dict(val=shared.val_losses(model, sets), bench=shared.benchmarks(model, args.bench_items))

    info = build(model, spec, args, job)
    trainable = shared.flat(model.trainable_parameters())
    n_train = lm.param_count(model.trainable_parameters())
    job.log(f"arm {args.arm}: {n_train:,} trainable parameters in {len(trainable)} arrays, {steps} steps")
    opt = shared.MasterAdamW(trainable, shared.schedule(spec["lr"], steps, warmup))
    del trainable
    meta = opt.load(job.dir / "ckpt")
    if meta is not None:
        model.load_weights(opt.params(), strict=False)
        job.log("resumed at step", opt.step)
    frame_steps = sorted(set(np.linspace(0, steps, args.frames).astype(int).tolist()))
    frame_dir = job.dir / "frames"
    frame_dir.mkdir(exist_ok=True)

    def snapshot(step):
        c = shared.capture(model, probe)
        np.savez_compressed(frame_dir / f"{step}.npz", **c)

    def evaluate(step, bench=False):
        rec = dict(step=step, tokens=step * args.batch * shared.SEQ, val=shared.val_losses(model, sets),
                   routing=shared.routing_share(model, {d: sets[d] for d in ("icelandic", "welsh", "english")}))
        if bench:
            rec["bench"] = shared.benchmarks(model, args.bench_items)
        job.metrics(rec)
        job.log("eval", step, {k: round(v, 4) for k, v in rec["val"].items()}, rec.get("bench", ""))
        return rec

    if opt.step == 0:
        initial = evaluate(0, bench=True)
        snapshot(0)
    else:
        initial = next(r for r in job.read_metrics() if r["step"] == 0)

    data = textdata.shard(spec["domain"], shared.TOK, "train", args.tokens + 2 * shared.SEQ)
    win = textdata.Windows(data, shared.SEQ, args.batch, seed=0)

    def loss_fn(model, ids):
        return lm.token_loss(model(ids[:, :-1]), ids[:, 1:])

    vg = nn.value_and_grad(model, loss_fn)
    rate = shared.Throughput()
    last_ckpt = time.time()
    losses = []
    step = opt.step
    stopped_early = False
    while step < steps:
        t0 = time.time()
        ids = mx.array(win.get(step))
        if args.micro == 1:
            loss, grads = vg(model, ids)
            mx.eval(loss, grads)
        else:  # equal chunks, so the mean of chunk means is the batch mean
            loss, grads = 0.0, None
            for part in mx.split(ids, args.micro, axis=0):
                part_loss, part_grads = vg(model, part)
                part_grads = tree_map(lambda g: g.astype(mx.float32), part_grads)
                grads = part_grads if grads is None else tree_map(mx.add, grads, part_grads)
                loss = loss + part_loss
                mx.eval(loss, grads)
                del part_grads
            loss = loss / args.micro
            grads = tree_map(lambda g: g / args.micro, grads)
            mx.eval(loss, grads)
        flat_grads = shared.flat(grads)
        if step <= 1 and spec["kind"] == "plug":
            groups = {}
            for k, g in flat_grads.items():
                name = k.rsplit(".", 1)[-1]
                groups[name] = groups.get(name, 0.0) + float(mx.sum(mx.square(g.astype(mx.float32))).item())
            info.setdefault("early_grad_norms", {})[step] = {k: v ** 0.5 for k, v in groups.items()}
            job.log(f"step {step} gradient norms:", info["early_grad_norms"][step])
        new, norm = opt.apply(flat_grads)
        del flat_grads
        del grads
        model.load_weights(new, strict=False)
        del new
        step = opt.step
        losses.append(float(loss.item()))
        rate.add(ids[:, :-1].size, time.time() - t0)
        if step % 10 == 0 or step == steps:
            tps = rate.rate()
            job.progress(args.arm, step, steps, tps, train_loss=float(np.mean(losses[-10:])), grad_norm=norm)
            job.metrics(dict(step=step, train_loss=float(np.mean(losses[-10:])), grad_norm=norm,
                             lr=opt.lr_fn(step - 1), tokens_per_second=tps), "train.jsonl")
        if step % args.eval_every == 0 and step < steps:
            evaluate(step)
        if step in frame_steps and step < steps:
            snapshot(step)
        if time.time() - last_ckpt > ckpt_minutes * 60:
            opt.save(job.dir / "ckpt", dict(arm=args.arm))
            last_ckpt = time.time()
        if budget.spent():
            stopped_early = True
            job.log("time cap reached at step", step)
            break

    final = evaluate(step, bench=True)
    snapshot(step)
    report = dict(arm=args.arm, spec=spec, trainable_parameters=n_train, peak_memory_gb=round(mx.get_peak_memory() / 1e9, 1), steps=step, planned_steps=steps,
                  tokens=step * args.batch * shared.SEQ, stopped_early=stopped_early, base=base,
                  initial=dict(val=initial["val"], bench=initial.get("bench")), final=dict(val=final["val"], bench=final["bench"]),
                  routing_final=final["routing"], **info)
    report["gain"] = base["val"][spec["domain"]] - final["val"][spec["domain"]]
    report["retention_change"] = {d: final["val"][d] / base["val"][d] - 1 for d in ("english", "python")}

    # Save the trained parts (small arms only) and check that unplugging restores the original exactly.
    if spec["kind"] == "plug":
        e = moe.expert_from_plugged(model)
        if spec["router_all"]:
            e["old_rows"] = mx.stack([b.old_rows for b in moe.moe_blocks(model)])
        mx.save_safetensors(str(job.dir / "expert.safetensors"), e, metadata=dict(domain=spec["domain"], arm=args.arm))
        moe.unplug(model)
    elif spec["kind"] == "lora":
        mx.save_safetensors(str(job.dir / "lora.safetensors"), shared.flat(model.trainable_parameters()))
        moe.remove_lora(model)
    if spec["kind"] != "full":
        after = model(ref[:, :-1])
        mx.eval(after)
        diff = float(mx.abs(after.astype(mx.float32) - base_ref.astype(mx.float32)).max())
        report["unplug"] = dict(max_abs_logit_diff=diff, identical=bool(mx.array_equal(after, base_ref).item()),
                                val=shared.val_losses(model, sets))
        job.log("unplugged:", report["unplug"])

    frames = sorted(int(p.stem) for p in frame_dir.glob("*.npz"))
    captures = {"base": dict(base_capture, label="Original OLMoE")}
    for s in frames:
        c = dict(np.load(frame_dir / f"{s}.npz"))
        rid = args.arm if s == 0 else f"{args.arm}@{s}"
        captures[rid] = dict(c, condition=args.arm, step=s, label=f"{args.arm} after {s} steps")
    conditions = [dict(id="base", label="Original OLMoE", description="Unchanged OLMoE-1B-7B-0924."),
                  dict(id=args.arm, label=args.arm.replace("_", " "), trained=True,
                       description=f"Trained on {spec['domain']} ({spec['kind']} arm, {n_train:,} trainable parameters).")]
    shared.write_atlas(job.dir / "atlas", f"E4 · {args.arm} · OLMoE learns {spec['domain'].capitalize()}",
                       "Residual stream of OLMoE-1B-7B on an Icelandic and an English probe, before and during "
                       f"training of the {args.arm.replace('_', ' ')} arm.", probe, captures, conditions,
                       {args.arm: "base"}, frames=frames, notes=dict(arm=args.arm, domain=spec["domain"]))
    # The trained parts are saved above; the resume state is no longer needed.
    for p in (job.dir / "ckpt").glob("*"):
        p.unlink()
    shutil.rmtree(frame_dir, ignore_errors=True)  # raw snapshots; the atlas bundle holds them
    job.finish("trained", **report)


if __name__ == "__main__":
    main()
