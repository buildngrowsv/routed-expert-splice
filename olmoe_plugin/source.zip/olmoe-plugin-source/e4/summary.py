"""prog-e4-summary: hot-swap the Icelandic and Welsh experts, compare every arm, decide.

Reads the result of each arm job, plugs the trained Icelandic and Welsh experts into the
original model one at a time and together (66 experts per layer), and applies the
pre-registered success rule from protocols/E4.md.
"""
import argparse
import json

import mlx.core as mx
import numpy as np

from common.job import Job, read_json
from common.paths import job_output
from e4 import moe, shared
from e4.olmoe import load
from e4.train import ARMS, job_id

EXPERT_KEYS = ("gate_w", "up_w", "down_w", "rows")


def load_expert(arm):
    path = job_output(job_id(arm)) / "expert.safetensors"
    if not path.exists():
        return None
    e = mx.load(str(path))
    return {k: e[k] for k in EXPERT_KEYS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--val-windows", type=int, default=64)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    if args.smoke:
        args.val_windows = 4
    job = Job("prog-e4-summary", vars(args))
    results = {arm: read_json(job_output(job_id(arm)) / "result.json") for arm in ARMS}
    results["plug_copy"] = read_json(job_output("prog-e4-plug-copy") / "result.json")  # ablation: copied down projection
    have = {a: r for a, r in results.items() if r}
    job.log("arm results found:", sorted(have))

    model, _ = load()
    sets = shared.val_sets(args.val_windows)
    probe, _ = shared.probe_ids()
    experts = {"icelandic": load_expert("plug"), "welsh": load_expert("plug_welsh")}
    combos = {"base": []}
    if experts["icelandic"] is not None:
        combos["plug_icelandic"] = ["icelandic"]
    if experts["welsh"] is not None:
        combos["plug_welsh"] = ["welsh"]
    if len(combos) == 3:
        combos["both"] = ["icelandic", "welsh"]

    swap, captures = {}, {}
    for name, which in combos.items():
        if which:
            moe.plug(model, [experts[w] for w in which])
        swap[name] = dict(experts=which, val=shared.val_losses(model, sets),
                          routing=shared.routing_share(model, {d: sets[d] for d in ("icelandic", "welsh", "english")}))
        captures[name] = dict(shared.capture(model, probe), label=name.replace("_", " "))
        moe.unplug(model)
        job.log(name, {k: round(v, 4) for k, v in swap[name]["val"].items()})

    # Comparison table against the base scores the arms used.
    base = next((r["base"] for r in have.values()), None) or dict(val=swap["base"]["val"])
    table = {}
    full_gain = have.get("full", {}).get("gain")
    if full_gain is not None and full_gain <= 0:
        full_gain = None  # full fine-tuning did not improve the domain; recovery is undefined
    for arm, r in have.items():
        table[arm] = dict(domain=r["spec"]["domain"], trainable=r["trainable_parameters"], tokens=r["tokens"],
                          gain=r["gain"], recovery=(r["gain"] / full_gain) if full_gain and r["spec"]["domain"] == "icelandic" else None,
                          english_change=r["retention_change"]["english"], python_change=r["retention_change"]["python"],
                          bench_final=r["final"]["bench"], bench_base=r["base"].get("bench"),
                          unplug_identical=(r.get("unplug") or {}).get("identical"))

    # If full fine-tuning hit its time cap before the planned tokens, compare at the last
    # evaluation step both arms reached, so the two gains use the same number of tokens.
    matched = None
    if full_gain is not None and "plug" in have and have["full"].get("stopped_early"):
        def curve(arm):
            path = job_output(job_id(arm)) / "metrics.jsonl"
            out = {}
            for line in path.read_text().splitlines():
                r = json.loads(line)
                if "val" in r:
                    out[r["step"]] = r["val"]["icelandic"]
            return out
        cp, cf = curve("plug"), curve("full")
        common = sorted(set(cp) & set(cf) - {0})
        b0 = base["val"]["icelandic"]
        common = [s for s in common if b0 - cf[s] > 0]
        if common:
            s = common[-1]
            matched = dict(step=s, plug_gain=b0 - cp[s], full_gain=b0 - cf[s], recovery=(b0 - cp[s]) / (b0 - cf[s]))
            table["plug"]["recovery_matched"] = matched["recovery"]

    plug = table.get("plug")
    if plug is None or full_gain is None:
        decision = "plugin_unresolved"
    else:
        recovery = matched["recovery"] if matched else plug["recovery"]
        retained = plug["english_change"] <= 0.01 and plug["python_change"] <= 0.01
        exact = bool(plug["unplug_identical"])
        if recovery >= 0.7 and retained and exact:
            decision = "plugin_success"
        elif recovery >= 0.35 and exact:
            decision = "plugin_partial"
        else:
            decision = "plugin_null"

    lines = ["| Arm | Domain | Trainable | Tokens | Gain (nats) | Share of full gain | English | Python | Unplugs exactly |",
             "|---|---|---:|---:|---:|---:|---:|---:|---|"]
    for arm, t in table.items():
        rec = "" if t["recovery"] is None else f"{t['recovery']:.0%}"
        unp = {True: "yes", False: "no", None: "n/a"}[t["unplug_identical"]]
        lines.append(f"| {arm} | {t['domain']} | {t['trainable']:,} | {t['tokens']:,} | {t['gain']:.3f} | {rec} | "
                     f"{t['english_change']:+.2%} | {t['python_change']:+.2%} | {unp} |")
    lines += ["", "Hot-swap validation loss (nats per token):", "",
              "| Plugged | " + " | ".join(shared.DOMAINS) + " |", "|---|" + "---:|" * len(shared.DOMAINS)]
    for name, s in swap.items():
        lines.append(f"| {name} | " + " | ".join(f"{s['val'][d]:.4f}" for d in shared.DOMAINS) + " |")
    (job.dir / "results.md").write_text("\n".join(lines) + "\n")

    conditions = [dict(id=n, label=c["label"], description=f"Plug-in experts: {', '.join(combos[n]) or 'none'}.")
                  for n, c in captures.items()]
    shared.write_atlas(job.dir / "atlas", "E4 · hot-swapping language experts in OLMoE",
                       "OLMoE-1B-7B with the trained Icelandic and Welsh plug-in experts, one at a time and together.",
                       probe, captures, conditions, {n: "base" for n in captures if n != "base"},
                       notes=dict(combos=combos))
    job.finish(decision, base=base, table=table, hot_swap=swap, full_gain=full_gain, matched=matched)


if __name__ == "__main__":
    main()
